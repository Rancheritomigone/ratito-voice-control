plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ratito.voicecontrol"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ratito.voicecontrol"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
