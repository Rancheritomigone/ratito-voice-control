package com.ratito.voicecontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(18, 24, 38))
        }
        val title = TextView(this).apply {
            text = "RATITO VOICE CONTROL"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Prototipo inicial\n\nLa escucha continua puede estar limitada por Android."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "Activar Ratito"
            setOnClickListener { requestPermissionsAndStart() }
        }
        val overlay = Button(this).apply {
            text = "Permitir botón flotante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, VoiceService::class.java).setAction(VoiceService.ACTION_SHOW_OVERLAY))
                }
            }
        }
        val stop = Button(this).apply {
            text = "Detener Ratito"
            setOnClickListener {
                stopService(Intent(this@MainActivity, VoiceService::class.java))
                status.text = "Ratito detenido."
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(overlay)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 40)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Primero habilitá el permiso de ventana flotante y luego volvé a tocar Activar."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        status.text = "Ratito activado. Decí: «Ratito, siguiente» o «Ratito, pausar»."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 40 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            requestPermissionsAndStart()
        } else if (requestCode == 40) {
            status.text = "Hace falta permiso de micrófono para reconocer comandos."
        }
    }
}
