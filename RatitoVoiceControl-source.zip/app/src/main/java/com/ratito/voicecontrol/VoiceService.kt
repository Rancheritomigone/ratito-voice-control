package com.ratito.voicecontrol

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.graphics.Color
import android.view.View
import android.view.WindowManager.LayoutParams
import java.util.Locale

class VoiceService : Service() {
    companion object {
        const val ACTION_START = "com.ratito.START"
        const val ACTION_SHOW_OVERLAY = "com.ratito.SHOW_OVERLAY"
        private const val CHANNEL_ID = "ratito_voice"
        private const val NOTIFICATION_ID = 7401
    }

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var sawWakeWord = false
    private var lastWakeAt = 0L
    private var overlayView: View? = null
    private var windowManager: WindowManager? = null
    private var restartCount = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        when (intent?.action) {
            ACTION_SHOW_OVERLAY -> showOverlay()
            ACTION_START -> {
                showOverlay()
                beginListening()
            }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Ratito está activo")
            .setContentText("Escuchando comandos de voz")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Ratito Voice Control", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        listening = true
        restartListening()
    }

    private fun restartListening() {
        if (!listening) return
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleRestart() }
                override fun onResults(results: android.os.Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    matches.firstOrNull()?.let { handlePhrase(it.lowercase(Locale("es", "AR"))) }
                    scheduleRestart()
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    matches.firstOrNull()?.let { handlePhrase(it.lowercase(Locale("es", "AR"))) }
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(speechIntent)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    private fun scheduleRestart() {
        if (!listening) return
        val delay = if (restartCount++ < 4) 500L else 1800L
        android.os.Handler(mainLooper).postDelayed({ restartListening() }, delay)
    }

    private fun handlePhrase(phrase: String) {
        val now = SystemClock.elapsedRealtime()
        if (phrase.contains("ratito")) {
            sawWakeWord = true
            lastWakeAt = now
            val afterWake = phrase.substringAfter("ratito").trim()
            if (afterWake.isNotBlank()) executeCommand(afterWake)
            return
        }
        if (sawWakeWord && now - lastWakeAt < 5000L) {
            executeCommand(phrase)
            sawWakeWord = false
        } else if (now - lastWakeAt >= 5000L) {
            sawWakeWord = false
        }
    }

    private fun executeCommand(raw: String) {
        val text = raw.lowercase(Locale("es", "AR"))
        when {
            text.contains("siguiente") || text.contains("próximo") || text.contains("proximo") -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            text.contains("anterior") || text.contains("atrás") || text.contains("atras") -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            text.contains("paus") || text.contains("deten") -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
            text.contains("continu") || text.contains("reanud") || text.contains("reproduc") -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
            text.contains("silencio") || text.contains("silenciar") -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            }
            text.contains("sub") && text.contains("volumen") -> adjustVolume(AudioManager.ADJUST_RAISE)
            text.contains("baj") && text.contains("volumen") -> adjustVolume(AudioManager.ADJUST_LOWER)
            text.contains("máximo") || text.contains("maximo") -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
            }
        }
    }

    private fun adjustVolume(direction: Int) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0)
    }

    private fun mediaKey(keyCode: Int) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val down = android.view.KeyEvent(android.os.SystemClock.uptimeMillis(), android.os.SystemClock.uptimeMillis(), android.view.KeyEvent.ACTION_DOWN, keyCode, 0)
        val up = android.view.KeyEvent(android.os.SystemClock.uptimeMillis(), android.os.SystemClock.uptimeMillis(), android.view.KeyEvent.ACTION_UP, keyCode, 0)
        audio.dispatchMediaKeyEvent(down)
        audio.dispatchMediaKeyEvent(up)
    }

    private fun showOverlay() {
        if (overlayView != null || !android.provider.Settings.canDrawOverlays(this)) return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.argb(230, 24, 34, 52))
        }
        val toggle = Button(this).apply {
            text = "🎙 Ratito"
            setOnClickListener { if (!listening) beginListening() else { listening = false; recognizer?.cancel(); text = "🎙 Activar" } }
        }
        val pause = Button(this).apply { text = "⏸"; setOnClickListener { mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) } }
        val next = Button(this).apply { text = "⏭"; setOnClickListener { mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT) } }
        val up = Button(this).apply { text = "Vol +"; setOnClickListener { adjustVolume(AudioManager.ADJUST_RAISE) } }
        val down = Button(this).apply { text = "Vol −"; setOnClickListener { adjustVolume(AudioManager.ADJUST_LOWER) } }
        panel.addView(toggle); panel.addView(pause); panel.addView(next); panel.addView(up); panel.addView(down)
        val params = LayoutParams(
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 12; y = 0 }
        try {
            windowManager?.addView(panel, params)
            overlayView = panel
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        recognizer = null
        overlayView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        overlayView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
